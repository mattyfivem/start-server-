In the next few days, I will release one of the latest versions of RageUI. This one will probably have no support from me, and you will have a commercial right on it without any counterpart, only a thank you.

This version will be less customizable, and much more powerful, in order to meet MY requirements, and not those of the community.
